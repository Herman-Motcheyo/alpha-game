package com.alpha.alphabackend.entity;

public class Dashbord {
    
    private int idDash;
    
}
