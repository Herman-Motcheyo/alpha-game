package com.alpha.alphabackend.entity;

import javax.persistence.Entity;


public class Configuration {
    private int IdCon;
    private Long timing;
    private String typeJeu;

}
