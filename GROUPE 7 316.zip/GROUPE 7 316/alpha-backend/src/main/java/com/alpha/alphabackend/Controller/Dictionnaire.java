package com.alpha.alphabackend.Controller;

import java.io.Serializable;
import java.util.LinkedList;

import com.alpha.alphabackend.entity.Mot;
import com.alpha.alphabackend.service.MotService;
import com.fasterxml.jackson.annotation.JsonAlias;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;
@RestController  
@RequestMapping( path = "mot")
@CrossOrigin
public class Dictionnaire {
  private String url = "https://api.dictionaryapi.dev/api/v2/entries/en_US/";

  @Autowired
  private MotService motService;
  // private RestTemplate restTemplate;

  @GetMapping("/{wordUser}")
  public LinkedList<String> getWord(@PathVariable("wordUser") String wordUser) {
    char c = wordUser.charAt(0);  
    return motService.getWords(c);
  }

}
// RestTemplate rest = new RestTemplate();
// url += wordUser;
// String result = rest.getForObject(url, String.class);
// sonAlias x =
// restTemplate.getForObject("https://api.dictionaryapi.dev/api/v2/entries/en_US/hello"
// , JsonAlias.class);
// System.out.println(result+"helloword");