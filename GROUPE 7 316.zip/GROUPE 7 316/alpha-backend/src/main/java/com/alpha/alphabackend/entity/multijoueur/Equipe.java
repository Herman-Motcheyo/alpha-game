package com.alpha.alphabackend.entity.multijoueur;

public class Equipe {

    private int id;
    private String couleur;
}
