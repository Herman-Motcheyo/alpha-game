package com.alpha.alphabackend.Controller;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import com.alpha.alphabackend.entity.Joueur;
import com.alpha.alphabackend.service.JoueurService;
import com.alpha.alphabackend.service.ValidationJoueurService;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "joueurs")
public class JoueurController {
    
    private final JoueurService joueurService; 

    @Autowired
    private ValidationJoueurService validationJoueurService;

    @Autowired
    public JoueurController(JoueurService joueurService){
        this.joueurService = joueurService;
    }
    
    @GetMapping
    public List<Joueur> getJoueurs(){
      return joueurService.getJoueurs();
    }
/*    
    @PostMapping
    public ResponseEntity<?> registerNewJoueur(@Valid @RequestBody Joueur joueur , BindingResult result){
        ResponseEntity error = validationJoueurService.validate(result);
        if (error != null) {
            return error;
        }
        Joueur joueur2 = joueurService.addNewJoueur(joueur);
    }
*/

    @PostMapping
    public void registerNewJoueur(@RequestBody Joueur joueur){
        joueurService.addNewJoueur(joueur);
    }

    @DeleteMapping(path = "/{id}")
    public void deleteJoueur(@PathVariable("id") Integer id){
       joueurService.deleteJoueur(id);
    }
}
