package com.alpha.alphabackend.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Mot {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) 
    private int id ;
   
    private String mot;
    private String audio;
    
    public Mot(int i, String string, String string2) {
        this.id = i;
        this.mot = string;
        this.audio=string2;
    }
    public String getAudio() {
        return audio;
    }
    public int getId() {
        return id;
    }
    public String getMot() {
        return mot;
    }
    public void setAudio(String audio) {
        this.audio = audio;
    }
    public void setMot(String mot) {
        this.mot = mot;
    }
    public void setId(int id) {
        this.id = id;
    }
    @Override
public String toString() {
	return "Mot [id=" + id + ", mot=" + mot + ", audio=" + audio  + "]";
}
}
