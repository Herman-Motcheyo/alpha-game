package com.alpha.alphabackend.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;
import org.springframework.stereotype.Service;

@Service
public class MotService {
    

    public  LinkedList<String> getWords(char firstLetter) {
        String filePath  = "src/words_alpha.txt";
		LinkedList<String> words = new LinkedList<String>();
		File file = new File(filePath);
		Scanner fileReader = null;
		String line;
		try {
			fileReader = new Scanner(file);
			while(fileReader.hasNext()) {
				line = fileReader.nextLine();
				if(line.charAt(0) == firstLetter) {
					words.add(line);
				}
			}
		} catch (FileNotFoundException e) {
			System.out.printf("le fichier %s n'existe pas" , filePath);
			e.printStackTrace();
		}
		
		fileReader.close();
		return words;
	}
}
