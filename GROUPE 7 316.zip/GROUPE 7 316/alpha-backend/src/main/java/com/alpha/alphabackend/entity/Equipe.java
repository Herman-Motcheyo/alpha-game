package com.alpha.alphabackend.entity;

public class Equipe {
    private int idEquipe;
    private String nom;
}
