package com.alpha.alphabackend.entity;

public class Partie {
    private int id ;
    private String nomPartie;
    private boolean estGagne;
    private Joueur joueur;
}
