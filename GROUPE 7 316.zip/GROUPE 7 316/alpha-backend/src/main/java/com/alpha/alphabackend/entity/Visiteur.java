package com.alpha.alphabackend.entity;

public class Visiteur {
    
}
