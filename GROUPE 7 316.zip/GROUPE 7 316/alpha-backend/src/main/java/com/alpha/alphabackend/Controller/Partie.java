package com.alpha.alphabackend.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("api/v1/partie")
public class Partie {
     
    @GetMapping
    public void test1(){
        System.out.println("dedans hjgjjhgjgjhgjh");
    }
}
