# Groupe  7 
 ## TCHENEGHON MOTCHEYO HERMAN 18T2640
 ## MACHE MBOUM VANELLE BLONDE 18T2858
 
 # Utilisation dossier AlphaBox ='frontend' 

 ### Dictionnaire
- # prerequis : connection

 on entre le mot et cela nous retourne le signification du mot et synonyme si l'api contient le mot 

 ### puzzle 

 - # prerequis : 
# npm et nodejs : pour installer npm et nodejs
sudo apt update
sudo apt install nodejs npm

ensuite , se deplacer dans le dossier Alphabox puis ''puzzle'' 
et taper 
# npm install 


### images and word 
 - # prerequis : Aucune precondition  

 # Utilisation dossier alpha-backend 
Spring Boot Application  neccessite  mysql installé et modifier le fichier 
# pom.xml pour inserer les modifications correspondants à la bd